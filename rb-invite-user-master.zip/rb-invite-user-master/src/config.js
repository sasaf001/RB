

export const OKTA_URL = "https://redbullsandbox.oktapreview.com";
export const OKTA_API_URL = "https://rb-proxy-test.azurewebsites.net/api/HttpTrigger1?code=h5Uec1BSL9gUNG9TSSpGAULdgM1PoQKeq3yoZ5YNr7vSAzFuOJLqRw==";
export const OKTA_WORKFLOW_REQUEST_URL = "https://rb-proxy-test.azurewebsites.net/api/createRequest?code=ZaNk6s94N1l-8zhroqg7Nq0b3dV69y1K96kIlPQVBHwPAzFuvSQEAw==";