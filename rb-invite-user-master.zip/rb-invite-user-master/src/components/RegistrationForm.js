import React, { useState, useEffect } from 'react';
import './RegistrationForm.css'; 
import Logo from '../utils/Logo'; 
import Select from 'react-select';
import createUser from '../API/createUser'; 
import { fetchUserInformation } from '../API/fetchUserInformation'; 

const RegistrationForm = ({ onRegistrationSuccess }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    distributorPartner: '',
  });

  const [fieldErrors, setFieldErrors] = useState({});
  const [groups, setGroups] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchUserInformation() // angepasster Funktionsaufruf
      .then(data => {
        if (data.groups && Array.isArray(data.groups)) { // Sicherstellen, dass groups ein Array ist
          setGroups(data.groups.map(groupName => ({ value: groupName, label: groupName })));
        } else {
          console.error('Expected groups to be an array, received:', data.groups);
        }
      })
      .catch(error => {
        console.error('Error fetching user information:', error);
        setError('Failed to fetch distributor partners');
      });
  }, []);

  const validateEmail = (email) => {
    const emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\\.,;:\s@\"]+\.)+[^<>()[\]\\.,;:\s@\"]{2,})$/i;
    return emailRegex.test(email);
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setFieldErrors({ ...fieldErrors, [e.target.name]: '' });
  };

  const handleSelectChange = (selectedOption, action) => {
    setFormData({ ...formData, [action.name]: selectedOption ? selectedOption.label : '' });
    setFieldErrors({ ...fieldErrors, [action.name]: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let newErrors = {};
    let isFormFullyFilled = true;

    Object.keys(formData).forEach(key => {
      if (!formData[key].trim()) {
        isFormFullyFilled = false;
        newErrors[key] = 'This field is required';
      }
    });

    if (!isFormFullyFilled) {
      setFieldErrors(newErrors);
      setError('All fields are required. Please complete the missing information.');
      return;
    }

    if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
      setFieldErrors(newErrors);
      setError('Please enter a valid email address.');
      return;
    }

    setError('');
    setFieldErrors({});

    try {
      const userResponse = await createUser({
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        groupName: formData.distributorPartner,
      });

      if (userResponse.success) {
        onRegistrationSuccess(true);
      } else {
        setError(userResponse.message || 'Registration failed. Please try again.');
      }
    } catch (error) {
      console.error('Error during registration:', error);
      setError(error.message || 'Registration failed. Please try again.');
      onRegistrationSuccess(false);
    }
  };

  return (
    <div className="registration-form-container">
      <form className="registration-form" onSubmit={handleSubmit} noValidate>
        <div className="registration-form-logo-placeholder"><Logo /></div>
        <input type="text" name="firstName" placeholder="First Name" className={fieldErrors.firstName ? 'input-error' : ''} value={formData.firstName} onChange={handleInputChange} />
        <input type="text" name="lastName" placeholder="Last Name" className={fieldErrors.lastName ? 'input-error' : ''} value={formData.lastName} onChange={handleInputChange} />
        <input type="email" name="email" placeholder="Email" className={fieldErrors.email ? 'input-error' : ''} value={formData.email} onChange={handleInputChange} />
        <Select name="distributorPartner" options={groups} value={groups.find(option => option.value === formData.distributorPartner) || null} onChange={handleSelectChange} placeholder="Distributor Partners" classNamePrefix="select" />
        {error && <p className="form-error">{error}</p>}
        <button type="submit" className="button">Invite</button>
      </form>
    </div>
  );
};

export default RegistrationForm;
