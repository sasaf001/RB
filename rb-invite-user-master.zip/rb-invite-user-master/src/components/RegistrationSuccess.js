import React, { useEffect } from 'react';
import { useOktaAuth } from '@okta/okta-react';

const AutoLogout = () => {
  const { oktaAuth } = useOktaAuth();

  useEffect(() => {
    const logout = async () => {
      await oktaAuth.signOut(); // Benutzer ausloggen
      window.location.href = '/.auth/login'; // Benutzer zur gewünschten Seite umleiten
    };

    logout(); // Logout ausführen, wenn die Komponente geladen wird
  }, []); // Leerer Abhängigkeitsarray, um den Effekt nur einmal auszuführen

  return null; // Die Komponente rendert nichts
};

export default AutoLogout;