import React, { useState, useEffect } from 'react';
import './RegistrationForm.css';
import Logo from '../utils/Logo';

import createUser from '../API/createUser';
import fetchGroups from '../API/fetchGroup';
import checkPasswordRequirements from '../helper/passwordCheck';

const RegistrationForm = ({ onRegistrationSuccess }) => { // Prop für den Erfolgs-Callback hinzugefügt
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    country: '',
    distributorPartner: '',
  });

  const [groups, setGroups] = useState([]);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredGroups = searchTerm.length === 0
    ? groups
    : groups.filter(group =>
        group.profile.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

  useEffect(() => {
    if (formData.country) {
      fetchGroups(formData.country)
        .then(data => {
          setGroups(data);
        })
        .catch(error => {
          console.error('Error fetching groups:', error);
          setError('Failed to fetch distributor partners');
        });
    } else {
      setGroups([]);
    }
  }, [formData.country]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const isFormValid = Object.values(formData).every(value => value.trim() !== '');
    if (!isFormValid) {
      setError('Please complete all fields');
      return;
    }

    const passwordError = checkPasswordRequirements(formData.password, formData.email, formData.firstName, formData.lastName);
    if (passwordError) {
      setError(passwordError);
      return;
    }

    try {
      await createUser({
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        password: formData.password,
        groupId: formData.distributorPartner,
      });
      onRegistrationSuccess(); // Aufrufen der Callback-Funktion bei Erfolg
    } catch (error) {
      setError('Registration failed. Please try again.');
    }
  };
  

  return (
    <div className="registration-form-container">
      <form className="registration-form" onSubmit={handleSubmit}>
        <div className="logo-placeholder"><Logo /></div>
        <p>Please continue filling out your profile</p>
        <input
          type="text"
          name="firstName"
          placeholder="Vorname"
          value={formData.firstName}
          onChange={handleChange}
        />
        <input
          type="text"
          name="lastName"
          placeholder="Nachname"
          value={formData.lastName}
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Passwort"
          value={formData.password}
          onChange={handleChange}
        />
        {/* Länderauswahl */}
        <select
          name="country"
          value={formData.country}
          onChange={handleChange}
          className={formData.country ? 'selected' : 'not-selected'}
        >
          <option value="">Country</option>
          <option value="US">US</option>
          <option value="Canada">Canada</option>
          <option value="Brazil">Brazil</option>
        </select>
        {formData.country && (
          <select
            name="distributorPartner"
            value={formData.distributorPartner}
            onChange={handleChange}
            className={formData.distributorPartner ? 'selected' : 'not-selected'}
          >
            <option value="">Distributor Partners</option>
            {groups.map(group => (
              <option key={group.id} value={group.id}>{group.profile.name}</option>
            ))}
          </select>
        )}
        {error && <p className="form-error">{error}</p>}
        <button type="submit">Complete Registration</button>
      </form>
    </div>
  );
};

export default RegistrationForm;
