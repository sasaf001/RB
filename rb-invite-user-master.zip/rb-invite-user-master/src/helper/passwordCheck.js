function checkPasswordRequirements(password, email, firstName, lastName) {
    const emailLocalPart = email.split('@')[0].toLowerCase();
    const lowerCasePassword = password.toLowerCase(); 
    const lowerCaseFirstName = firstName.toLowerCase();
    const lowerCaseLastName = lastName.toLowerCase();

    const requirements = [
        {
            test: (password) => password.length >= 1,
            message: "The password must be at least 12 characters long."
        },
        {
            test: (password) => /[a-z]/.test(password),
            message: "The password must contain at least one lowercase letter."
        },
        {
            test: (password) => /[A-Z]/.test(password),
            message: "The password must contain at least one uppercase letter."
        },
        {
            test: (password) => /[0-9]/.test(password),
            message: "The password must contain at least one number."
        },
        {
            test: (password) => !lowerCasePassword.includes(emailLocalPart),
            message: "The password must not contain parts of your email address."
        },
        {
            test: (password) => !lowerCasePassword.includes(lowerCaseFirstName),
            message: "The password cannot contain your first name."
        },
        {
            test: (password) => !lowerCasePassword.includes(lowerCaseLastName),
            message: "The password cannot contain your last name."
        }
    ];

    const failedRequirements = requirements
        .filter(req => !req.test(password))
        .map(req => req.message)
        .join('\n');

    return failedRequirements;
}




export default checkPasswordRequirements;
