export const fetchUserInformation = async () => {
  try {
    const response = await fetch('/.auth/me');
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    const clientPrincipal = data?.clientPrincipal;

    if (!clientPrincipal) {
      throw new Error('No client principal data found');
    }

    const userClaims = clientPrincipal.claims;

    // Extrahiere Benutzerdaten aus den Claims
    const username = userClaims.find(claim => claim.typ === "name")?.val;
    const email = userClaims.find(claim => claim.typ === "preferred_username")?.val;
    const userId = clientPrincipal.userId;

    // Extrahiere Gruppeninformationen aus den Claims
    const groups = userClaims
      .filter(claim => claim.typ === "groups")
      .map(group => group.val.replace("da_", "")); // Entferne "da_" Präfix falls vorhanden

    return {
      username,
      email,
      userId,
      groups
    };
  } catch (error) {
    console.error('Failed to fetch user information:', error);
    throw error; // Weitergeben des Fehlers an die aufrufende Komponente
  }
};

export default fetchUserInformation;
