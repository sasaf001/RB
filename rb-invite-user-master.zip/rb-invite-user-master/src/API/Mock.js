const mockUserData = {
    "clientPrincipal": {
      "identityProvider": "myprovider",
      "userId": "00u6q372f1VXh9fLW0x7",
      "userDetails": "Roy Mueller",
      "userRoles": [
        "authenticated",
        "anonymous"
      ],
      "claims": [
        {
          "typ": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
          "val": "00u6q372f1VXh9fLW0x7"
        },
        {
          "typ": "name",
          "val": "Roy Mueller"
        },
        {
          "typ": "ver",
          "val": "1"
        },
        {
          "typ": "iss",
          "val": "https://spark-d.redbull.com"
        },
        {
          "typ": "aud",
          "val": "0oa7kqfvmkr6oPsXe0x7"
        },
        {
          "typ": "iat",
          "val": "1713346203"
        },
        {
          "typ": "exp",
          "val": "1713349803"
        },
        {
          "typ": "jti",
          "val": "ID.0q1bfslrTjD_eoy_yukR-uP7tbh6WGuacQaxICwxcr0"
        },
        {
          "typ": "http://schemas.microsoft.com/claims/authnmethodsreferences",
          "val": "mfa"
        },
        {
          "typ": "http://schemas.microsoft.com/claims/authnmethodsreferences",
          "val": "pwd"
        },
        {
          "typ": "http://schemas.microsoft.com/claims/authnmethodsreferences",
          "val": "email"
        },
        {
          "typ": "http://schemas.microsoft.com/identity/claims/identityprovider",
          "val": "00o655r7n4EdoRQaW0x7"
        },
        {
          "typ": "nonce",
          "val": "c26d5389c6014c6c8652c877d99d1778_20240417093503"
        },
        {
          "typ": "preferred_username",
          "val": "roy.mueller@skaylink.com"
        },
        {
          "typ": "auth_time",
          "val": "1713346201"
        },
        {
          "typ": "at_hash",
          "val": "CsVIkw4I-qq5lzz8wgeddQ"
        },
        {
          "typ": "groups",
          "val": "da_Ace Distributing"
        },
        {
            "typ": "groups",
            "val": "da_testGruppe"
        }
      ]
    }
  };
  
  export default mockUserData;
  