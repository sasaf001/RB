import { OKTA_API_URL } from '../config'; // Importieren des API-Tokens aus einer separaten Konfigurationsdatei
import fetchGroup from '../API/fetchGroup'; // oder der korrekte Pfad zu deiner Funktion

/**
 * Erstellt einen neuen Benutzer in Okta mit den gegebenen Details.
 * @param {Object} userDetails - Details des zu erstellenden Benutzers.
 */
const createUser = async (userDetails) => {
  const { firstName, lastName, email, groupName } = userDetails;

  try {
    // Ermittle die Gruppen-ID durch den Namen der Gruppe
    const group = await fetchGroup(groupName);
    if (!group || !group.id) {
      return {
        responseNumber: 404,
        success: false,
        errorCode: 'GroupNotFound',
        message: 'No group found with the provided name.',
      };
    }
    const groupId = group.id; // Setze die Gruppen-ID

    const url = `${OKTA_API_URL}&path=/api/v1/users?activate=true`; // URL für die Okta API.
    const headers = {
      'Content-Type': 'application/json',
      'Accept-Language': 'en-US',
    };
    const body = {
      profile: {
        firstName,
        lastName,
        email,
        login: email,
        selfRegister: true,
        regComplete: true,
      },
      groupIds: [groupId], // Füge die Gruppen-ID zum Anfragekörper hinzu
    };

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    const data = await response.json(); // Immer die Antwort in JSON umwandeln, egal ob Erfolg oder Fehler

    if (!response.ok) {
      let message = "An error has occurred. The user could not be created. Please try again.";
      if (data.errorCauses && data.errorCauses.length > 0 && data.errorCauses[0].errorSummary) {
        message = data.errorCauses[0].errorSummary;
      } else if (data.errorSummary) {
        message = data.errorSummary;
      }

      return {
        responseNumber: response.status,
        success: false,
        errorCode: data.errorCode,
        message: message,
      };
    }

    return {
      responseNumber: response.status,
      success: true,
      data: data,
    };

  } catch (error) {
    console.error('Error creating user:', error);
    return {
      responseNumber: 0,
      success: false,
      errorCode: 'NetworkError',
      message: 'An unexpected network error occurred.',
    };
  }
};

export default createUser;
