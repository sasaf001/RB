import { OKTA_API_URL } from '../config'; // Importieren des API-Tokens aus einer separaten Konfigurationsdatei



const fetchGroupByName = async (groupName) => {
  const queryParams = `/api/v1/groups?search=profile.name%20eq%20"${groupName}"`;

  try {
    const response = await fetch(`${OKTA_API_URL}&path=${queryParams}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    let data = await response.json();

    // Da der Gruppenname eindeutig sein sollte, erwarten wir maximal ein Ergebnis
    const group = data.length > 0 ? data[0] : null;

    return group; // Gibt die gefundene Gruppe zurück, oder null, wenn keine gefunden wurde
  } catch (error) {
    console.error('Failed to fetch group:', error);
    throw error;
  }
};

export default fetchGroupByName;
