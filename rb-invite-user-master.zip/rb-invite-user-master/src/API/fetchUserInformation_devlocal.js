import mockUserData from './Mock'; // Stelle sicher, dass der Pfad korrekt ist

// Funktion, um Benutzerinformationen zu extrahieren
export const fetchUserInformation = async () => {
  // Simuliere eine API-Aufrufverzögerung
  return new Promise((resolve) => {
    setTimeout(() => {
      const clientPrincipal = mockUserData.clientPrincipal;
      const userClaims = clientPrincipal.claims;
      const username = userClaims.find(claim => claim.typ === "name")?.val;
      const email = userClaims.find(claim => claim.typ === "preferred_username")?.val;
      const userId = clientPrincipal.userId;

      // Filter nur die Claims vom Typ "groups" und entferne den Präfix "da_"
      const groups = userClaims
        .filter(claim => claim.typ === "groups")
        .map(group => group.val.replace("da_", ""))
        .map(groupName => groupName); // Hier nur die Gruppennamen zurückgeben

      // Objekt mit den notwendigen Benutzerinformationen
      resolve({
        username,
        email,
        userId,
        groups
      });
    }, 500);
  });
}

export default fetchUserInformation;
