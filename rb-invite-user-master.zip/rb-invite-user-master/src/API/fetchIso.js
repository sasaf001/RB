// fetchIso.js
const fetchIsoCodes = async () => {
  try {
    const response = await fetch('https://restcountries.com/v3.1/all', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Network response was not ok');
    }

    const countries = await response.json();

    // Verarbeite die Daten und sortiere sie alphabetisch nach dem Namen des Landes
    const isoOptions = countries.map(country => ({
      value: country.cca2, // Verwende den CCA2-Code als Wert
      label: `${country.cca2} - ${country.name.common}`, // Kombiniere CCA2 und den allgemeinen Namen für das Label
    })).sort((a, b) => a.label.localeCompare(b.label)); // Alphabetische Sortierung

    // Rückgabe der verarbeiteten und sortierten ISO-Optionen
    return isoOptions;
  } catch (error) {
    console.error('Failed to fetch ISO codes:', error);
    throw error;
  }
};

export default fetchIsoCodes;
